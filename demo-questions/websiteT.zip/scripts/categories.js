let categories = new Map;

categories.set("#Theoretische Informatik", 2);


function setCategories(cg){
    categories = cg;
}

function getCategories(){
    return categories;
}
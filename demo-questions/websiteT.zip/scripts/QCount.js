let Qcount = null;

function setQcount(count){
    Qcount = count;
}

function getQcount(){
    return Qcount;
}

setQcount(2);

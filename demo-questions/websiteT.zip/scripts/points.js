points = [4,2]

function getQuestionPoints(){
    return points;
}
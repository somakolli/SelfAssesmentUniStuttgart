let solution = "";

function setSolution(input){
    solution = input;
}

function getSolution(){
    return solution;
}

/* Example */
setSolution("1010010");
/* Example */
